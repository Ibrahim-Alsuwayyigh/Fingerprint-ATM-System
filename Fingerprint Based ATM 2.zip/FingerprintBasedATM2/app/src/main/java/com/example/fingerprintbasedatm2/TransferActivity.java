package com.example.fingerprintbasedatm2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class TransferActivity extends AppCompatActivity {
        public static final String EXTRA_TEXT = "com.example.fingerprintbasedatm2.EXTRA_TEXT";
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("users");

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.transfer_activity);
                final EditText transferId = findViewById(R.id.transferid);
                final EditText transferM = findViewById(R.id.tranfermoney);
                final Button transferbtn = findViewById(R.id.transferbtn);
                Intent intent = getIntent();
                final String username = intent.getStringExtra(LoginPage.EXTRA_TEXT);
            Button restartButton = findViewById(R.id.restartButton);
            restartButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                }
            });

                transferbtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                final String transferToUsername = transferId.getText().toString();
                                String transferAmountStr = transferM.getText().toString();

                                if (!transferToUsername.isEmpty() && !transferAmountStr.isEmpty()) {
                                        final double transferAmount = Double.parseDouble(transferAmountStr);

                                        databaseReference.orderByChild("username").equalTo(username)
                                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                if (dataSnapshot.exists()) {
                                                                        DataSnapshot userSnapshot = dataSnapshot.getChildren().iterator().next();
                                                                        double senderBalance = userSnapshot.child("Balance").getValue(double.class);

                                                                        if (senderBalance >= transferAmount) {
                                                                            double newSenderBalance = senderBalance - transferAmount;
                                                                            userSnapshot.getRef().child("Balance").setValue(newSenderBalance)
                                                                                    .addOnCompleteListener(task -> {
                                                                                        if (task.isSuccessful()) {
                                                                                            databaseReference.orderByChild("username").equalTo(transferToUsername)
                                                                                                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                                                                                        @Override
                                                                                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                                                            if (dataSnapshot.exists()) {
                                                                                                                DataSnapshot recipientSnapshot = dataSnapshot.getChildren().iterator().next();
                                                                                                                double recipientBalance = recipientSnapshot.child("Balance").getValue(double.class);

                                                                                                                double newRecipientBalance = recipientBalance + transferAmount;
                                                                                                                recipientSnapshot.getRef().child("Balance").setValue(newRecipientBalance)
                                                                                                                        .addOnCompleteListener(task1 -> {
                                                                                                                            if (task1.isSuccessful()) {
                                                                                                                                Toast.makeText(TransferActivity.this, "Transfer successful!", Toast.LENGTH_SHORT).show();
                                                                                                                                Intent intent = new Intent(TransferActivity.this, TransactionActivity.class);
                                                                                                                                intent.putExtra(EXTRA_TEXT, username);
                                                                                                                                startActivity(intent);
                                                                                                                            } else {
                                                                                                                                Toast.makeText(TransferActivity.this, "Failed to update recipient's balance.", Toast.LENGTH_SHORT).show();
                                                                                                                            }
                                                                                                                        });
                                                                                                            } else {
                                                                                                                Toast.makeText(TransferActivity.this, "Recipient username not found.", Toast.LENGTH_SHORT).show();
                                                                                                            }
                                                                                                        }

                                                                                                        @Override
                                                                                                        public void onCancelled(@NonNull DatabaseError databaseError) {
                                                                                                            Toast.makeText(TransferActivity.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                                                                                                        }
                                                                                                    });
                                                                                        } else {
                                                                                            Toast.makeText(TransferActivity.this, "Failed to update sender's balance.", Toast.LENGTH_SHORT).show();
                                                                                        }
                                                                                    });
                                                                        }else {
                                                                                Toast.makeText(TransferActivity.this, "Insufficient balance for transfer.", Toast.LENGTH_SHORT).show();
                                                                        }
                                                                } else {
                                                                        Toast.makeText(TransferActivity.this, "Sender username not found.", Toast.LENGTH_SHORT).show();
                                                                }
                                                        }

                                                        @Override
                                                        public void onCancelled(@NonNull DatabaseError databaseError) {
                                                                Toast.makeText(TransferActivity.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                                                        }
                                                });
                                } else {
                                        Toast.makeText(TransferActivity.this, "Please enter recipient username and transfer amount.", Toast.LENGTH_SHORT).show();
                                }
                        }
                });
        }
        public void onClick (View view1){
                Intent intent2 = new Intent(this, TransactionActivity.class);
                final String username = intent2.getStringExtra(LoginPage.EXTRA_TEXT);
                intent2.putExtra(EXTRA_TEXT, username);
                startActivity(intent2);

        }
}
