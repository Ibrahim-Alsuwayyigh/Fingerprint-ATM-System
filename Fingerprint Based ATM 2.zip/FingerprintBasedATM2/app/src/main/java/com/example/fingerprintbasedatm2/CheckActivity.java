package com.example.fingerprintbasedatm2;

        import android.content.Intent;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;

        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;

        import com.google.android.gms.tasks.OnCompleteListener;
        import com.google.android.gms.tasks.OnFailureListener;
        import com.google.android.gms.tasks.Task;
        import com.google.firebase.Firebase;
        import com.google.firebase.database.DataSnapshot;
        import com.google.firebase.database.DatabaseError;
        import com.google.firebase.database.DatabaseKt;
        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;
        import com.google.firebase.database.ValueEventListener;

public class CheckActivity extends AppCompatActivity {
        public static final String EXTRA_TEXT = "com.example.fingerprintbasedatm2.EXTRA_TEXT";
        DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReferenceFromUrl("https://fingerprint-based-atm-f35c8-default-rtdb.firebaseio.com");
        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.checkbalance_activity);
                Intent intent = getIntent();
                 final String username = intent.getStringExtra(LoginPage.EXTRA_TEXT);

                TextView textView = findViewById(R.id.textview1);Button restartButton = findViewById(R.id.restartButton);
                restartButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                                finish();
                        }
                });

                DatabaseReference usersRef = databaseReference.child("users");

                usersRef.orderByChild("username").equalTo(username)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if (dataSnapshot.exists()) {
                                                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                                        String balance = String.valueOf(snapshot.child("Balance").getValue(double.class));
                                                        if (balance != null) {
                                                                textView.setText(balance);

                                                        } else {
                                                                textView.setText("Balance not found");
                                                        }
                                                }
                                        } else {
                                                textView.setText("User not found");
                                        }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                        Log.e("MainActivity", "Error retrieving data: ", databaseError.toException());
                                        textView.setText("Error fetching data");
                                }
                        });

        }
                public void onClick (View view1){
                        Intent intent2 = new Intent(this, TransactionActivity.class);
                        final String username = intent2.getStringExtra(LoginPage.EXTRA_TEXT);
                        intent2.putExtra(EXTRA_TEXT, username);
                        startActivity(intent2);

                }


}
