package com.example.fingerprintbasedatm2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.Firebase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseKt;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginPage extends AppCompatActivity {
       DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReferenceFromUrl("https://fingerprint-based-atm-f35c8-default-rtdb.firebaseio.com");
    public static final String EXTRA_TEXT = "com.example.fingerprintbasedatm2.EXTRA_TEXT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        final EditText username =findViewById(R.id.Username);
        final EditText password =findViewById(R.id.password);
        final Button loginbtn =findViewById(R.id.loginbtn);
        Button restartButton = findViewById(R.id.restartButton);
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
        loginbtn.setOnClickListener(new View.OnClickListener() {
           @Override
          public void onClick(View v) {
           final String Username = username.getText().toString();
            final String passwordtext = password.getText().toString();
        if (Username.isEmpty() || passwordtext.isEmpty()){
            Toast.makeText(LoginPage.this,"can not be empty",Toast.LENGTH_SHORT).show();
        }
        else {
            databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.hasChild(Username)){

                        final String getPassword = snapshot.child(Username).child("password").getValue(String.class);

                        if (getPassword.equals(passwordtext)){

                            Toast.makeText(LoginPage.this,"Successfully logged in ",Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(LoginPage.this, TransactionActivity.class);
                            intent.putExtra(EXTRA_TEXT, Username);
                            startActivity(intent);

                        }
                        else {
                            Toast.makeText(LoginPage.this,"Wrong Password ",Toast.LENGTH_SHORT).show();
                        }

                    }
                    else {
                        Toast.makeText(LoginPage.this,"Wrong Username",Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
        }
          });


    }  public void onClick(View view1) {
        Intent intent = getIntent();
        final String username = intent.getStringExtra(LoginPage.EXTRA_TEXT);
        Intent intent2 = new Intent(this, TransactionActivity.class);
        intent2.putExtra(EXTRA_TEXT, username);
        startActivity(intent2);
    }
}