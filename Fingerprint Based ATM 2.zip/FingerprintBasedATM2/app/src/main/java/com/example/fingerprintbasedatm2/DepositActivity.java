package com.example.fingerprintbasedatm2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DepositActivity extends AppCompatActivity {
    public static final String EXTRA_TEXT = "com.example.fingerprintbasedatm2.EXTRA_TEXT";
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("users");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.deposit_activity);
        final EditText deposit = findViewById(R.id.Deposittx);
        final Button depositbtn = findViewById(R.id.depositbtn);

        Intent intent = getIntent();
        final String username = intent.getStringExtra(LoginPage.EXTRA_TEXT);

        Button restartButton = findViewById(R.id.restartButton);
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });


        depositbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String depositAmountStr = deposit.getText().toString();
                if (!depositAmountStr.isEmpty()) {
                    double depositAmount = Double.parseDouble(depositAmountStr);

                    databaseReference.orderByChild("username").equalTo(username)
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.exists()) {
                                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                            double balance = snapshot.child("Balance").getValue(double.class);

                                            double newBalance = balance + depositAmount;

                                            snapshot.getRef().child("Balance").setValue(newBalance)
                                                    .addOnCompleteListener(updateTask -> {
                                                        if (updateTask.isSuccessful()) {
                                                            Toast.makeText(DepositActivity.this, "Balance updated successfully!", Toast.LENGTH_SHORT).show();
                                                            Intent intent3  = new Intent(DepositActivity.this, TransactionActivity.class);
                                                            intent3.putExtra(EXTRA_TEXT, username);
                                                            startActivity(intent3);
                                                        } else {
                                                            Toast.makeText(DepositActivity.this, "Failed to update balance.", Toast.LENGTH_SHORT).show();
                                                        }
                                                    });
                                        }
                                    } else {

                                        Toast.makeText(DepositActivity.this, "Username not found.", Toast.LENGTH_SHORT).show();
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                    Toast.makeText(DepositActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    Toast.makeText(DepositActivity.this, "Please enter a deposit amount.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void onClick(View view1) {
        Intent intent = getIntent();
        final String username = intent.getStringExtra(LoginPage.EXTRA_TEXT);
        Intent intent2 = new Intent(this, TransactionActivity.class);
        intent2.putExtra(EXTRA_TEXT, username);
        startActivity(intent2);
    }
}