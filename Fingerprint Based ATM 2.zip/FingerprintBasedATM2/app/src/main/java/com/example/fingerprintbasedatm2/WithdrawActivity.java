package com.example.fingerprintbasedatm2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class WithdrawActivity extends AppCompatActivity {
        public static final String EXTRA_TEXT = "com.example.fingerprintbasedatm2.EXTRA_TEXT";
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("users");

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.withdraw_activity);
                final EditText withdraw = findViewById(R.id.withdrawtx);
                final Button withdrawBtn = findViewById(R.id.withdrawbtn);
                Intent intent = getIntent();
                final String username = intent.getStringExtra(LoginPage.EXTRA_TEXT);
                Button restartButton = findViewById(R.id.restartButton);
                restartButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                                finish();
                        }
                });

                withdrawBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                String withdrawAmountStr = withdraw.getText().toString();
                                if (!withdrawAmountStr.isEmpty()) {
                                        double withdrawAmount = Double.parseDouble(withdrawAmountStr);

                                        databaseReference.orderByChild("username").equalTo(username)
                                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                                if (dataSnapshot.exists()) {
                                                                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                                                                double balance = snapshot.child("Balance").getValue(double.class);

                                                                                double newBalance = balance - withdrawAmount;

                                                                                if (newBalance < 0) {
                                                                                        Toast.makeText(WithdrawActivity.this, "Your balance is not enough to perform this transaction.", Toast.LENGTH_SHORT).show();
                                                                                } else {
                                                                                        snapshot.getRef().child("Balance").setValue(newBalance)
                                                                                                .addOnCompleteListener(updateTask -> {
                                                                                                        if (updateTask.isSuccessful()) {
                                                                                                                Toast.makeText(WithdrawActivity.this, "Balance updated successfully!", Toast.LENGTH_SHORT).show();
                                                                                                                Intent intent3 = new Intent(WithdrawActivity.this, TransactionActivity.class);
                                                                                                                intent3.putExtra(EXTRA_TEXT, username);
                                                                                                                startActivity(intent3);
                                                                                                        } else {
                                                                                                                Toast.makeText(WithdrawActivity.this, "Failed to update balance.", Toast.LENGTH_SHORT).show();
                                                                                                        }
                                                                                                });
                                                                                }
                                                                        }
                                                                } else {
                                                                        Toast.makeText(WithdrawActivity.this, "Username not found.", Toast.LENGTH_SHORT).show();
                                                                }
                                                        }

                                                        @Override
                                                        public void onCancelled(@NonNull DatabaseError error) {
                                                                Toast.makeText(WithdrawActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                                                        }
                                                });
                                } else {
                                        Toast.makeText(WithdrawActivity.this, "Please enter a withdrawal amount.", Toast.LENGTH_SHORT).show();
                                }
                        }
                });
        }

        public void onClick(View view1) {
                Intent intent = getIntent();
                final String username = intent.getStringExtra(LoginPage.EXTRA_TEXT);
                Intent intent2 = new Intent(this, TransactionActivity.class);
                intent2.putExtra(EXTRA_TEXT, username);
                startActivity(intent2);
        }
}