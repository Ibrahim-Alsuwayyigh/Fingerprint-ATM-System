package com.example.fingerprintbasedatm2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.Firebase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseKt;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;


public class TransactionActivity extends AppCompatActivity {
    public static final String EXTRA_TEXT = "com.example.fingerprintbasedatm2.EXTRA_TEXT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);
        Intent intent = getIntent();
        String username = intent.getStringExtra(LoginPage.EXTRA_TEXT);


        Button Transferbtn = findViewById(R.id.Transferbtn);
        Button Withdrawbtn = findViewById(R.id.Withdrawbtn);
        Button depositbtn = findViewById(R.id.depositbtn);
        Button Balancechebtn = findViewById(R.id.Balancechebtn);
        TextView textView1 = findViewById(R.id.textview1);
        textView1.setText(username);
        Button restartButton = findViewById(R.id.restartButton);
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });



        Transferbtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TransactionActivity.this, TransferActivity.class);
                intent.putExtra(EXTRA_TEXT, username);
                startActivity(intent);
            }
        });

        Withdrawbtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TransactionActivity.this, WithdrawActivity.class);
                intent.putExtra(EXTRA_TEXT, username);
                startActivity(intent);
            }
        });

        depositbtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TransactionActivity.this, DepositActivity.class);
                intent.putExtra(EXTRA_TEXT, username);
                startActivity(intent);
            }
        });

        Balancechebtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TransactionActivity.this, CheckActivity.class);
                intent.putExtra(EXTRA_TEXT, username);
                startActivity(intent);
            }
        });
    }
}